/**
* Template Name: Day - v4.3.0
* Template URL: https://bootstrapmade.com/day-multipurpose-html-template-for-free/
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/
(function() {
  "use strict";

  /**
   * Animation on scroll
   */
  window.addEventListener('load', () => {
    AOS.init({
      duration: 1000,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    })
  });
})()

  /*
    Animation for show phone in top bar
  */
function ocultar(){
  document.getElementById('phone').className = "hidden-phone";
  document.getElementById('name').className = "view-phone"
}

function mostrar(){
  document.getElementById('phone').className = "view-phone";
  document.getElementById('name').className = "hidden-phone";
}